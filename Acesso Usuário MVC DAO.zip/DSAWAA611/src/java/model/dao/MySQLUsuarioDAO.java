/* 
	Desenvolvimento de Software Avançado para Web
	AA6-11  Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581020	Marcio Rogério Porto 
*/
package model.dao;

import model.dao.interfaces.UsuarioDAO;
import model.beans.Usuario;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Esta classe possibilita a manipulação dos dados de usuarios no banco de dados
 */
public class MySQLUsuarioDAO implements UsuarioDAO
{
    private Session session;

   /**
    * Este método atualiza os dados de um usuario com base no objeto fornecido como parâmetro.
    */

    @Override
    public boolean update(Usuario usu) throws Exception {
        if(usu == null)
        throw new Exception("O parâmetro é nulo");

      session = MySQLUABDAOFactory.getInstance();
      Transaction tx = null;
      try
      {
        tx = session.beginTransaction();
        session.save(usu);
        tx.commit();
        return true;
      }
      catch(HibernateException ex)
      {
        ex.printStackTrace();
        tx.rollback();
      }
      finally
      {
        session.close();
      }
      return false;
    }

}
