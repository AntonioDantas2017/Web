/* 
	Desenvolvimento de Software Avançado para Web
	AA6-11  Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581020	Marcio Rogério Porto 
*/
package model.dao.interfaces;

import model.beans.Usuario;

/**
 * Esta interface define os métodos utilizados na manipulação de dados de usuários.
 */
public interface UsuarioDAO
{
   /**
    * Este método atualiza os dados de um usuário com base no objeto fornecido como parâmetro.
    */
   public boolean update(Usuario usuario) throws Exception;
}
