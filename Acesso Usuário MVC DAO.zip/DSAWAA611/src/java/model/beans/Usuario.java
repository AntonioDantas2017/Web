/* 
	Desenvolvimento de Software Avançado para Web
	AA6-11  Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581020	Marcio Rogério Porto 
*/
package model.beans;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Esta JavaBean representa um usuário.
 */
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable
{
    @Id
    @Column(name = "nome")
    private String nome;
    @Column(name = "idade")
    private String idade;
    @Column(name = "email")
    private String email;
    @Column(name = "endereco")
    private String endereco;
    @Column(name = "telefone")
    private String telefone;
    
    
    /**@param to set */
    public String getNome() { return nome; }
    public String getIdade() { return idade; }
    public String getEmail() { return email; }
    public String getTelefone() { return telefone; }
    public String getEndereco() { return endereco; }
    
    /**@return */
    public void setIdade(String idade) { this.idade = idade; }
    public void setEmail(String email) { this.email = email; }
    public void setNome(String nome) { this.nome = nome; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

}
