/* 
	Desenvolvimento de Software Avançado para Web
	AA6-11  Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581020	Marcio Rogério Porto 
*/
package controller;

import model.dao.MySQLUABDAOFactory;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.beans.Usuario;
import model.dao.MySQLUsuarioDAO;

/**
 * Esta classe manipula os dados do perfil do usuário do sistema
 */
public class ServletPerfilUsuario extends HttpServlet
{   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        
        String nome = (String) request.getParameter("nome");
        String idade = (String) request.getParameter("idade");
        String email = (String) request.getParameter("email");
        String endereco = (String) request.getParameter("endereco");
        String telefone = (String) request.getParameter("telefone");
        if(idade != null && !idade.equals("") && nome != null && !nome.equals("") && telefone != null && !telefone.equals("")
           && email != null && !email.equals("") && endereco != null && !endereco.equals(""))
        {
          try
          {
            MySQLUsuarioDAO usuarioDAO = new MySQLUsuarioDAO();
            Usuario usu = new Usuario();
            usu.setNome(nome);
            usu.setIdade(idade);
            usu.setEmail(email);
            usu.setEndereco(endereco);
            usu.setTelefone(telefone);
              
            if(usuarioDAO.update(usu))
             response.sendRedirect("paginaRetorno.jsp");
            else
              response.sendRedirect("erro.jsp?mensagemRetorno=Erro na inserção");
         }
          catch (Exception ex)
          {
            //System.err.println("Erro: " + ex.getMessage());
            response.sendRedirect("erro.jsp?mensagemRetorno="+ ex.getMessage());
          }
        }
    } 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
