create database dsawaa611;
use dsawaa611;
create table usuario (
codigo integer not null auto_increment, 
nome text not null,
idade text not null,
email text not null,
endereco text not null,
telefone text not null,
constraint Primary Key (codigo));

select * from usuario
