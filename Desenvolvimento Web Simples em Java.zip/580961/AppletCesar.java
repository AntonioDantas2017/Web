/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informação - G7 - UAB SJC - Ufscar 
 * Atividade AA6-1
 */

//Carregando bibiliotecas necessárias
import java.applet.Applet;
import java.awt.Button;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.List;
import java.awt.TextArea;

public class AppletCesar extends Applet implements ActionListener {

    //Objetos AWT para execução do Programa
    private Button btnCifra;
    private TextArea   txtOri;
    private TextArea   txtEnc;
    private Label lblOri;
    private Label lblEnc;
    private List cboPos;
   
    //Sobrescrevendo método de inicialização do programa
    @Override
    public void init() {
        //Criando botão com evento de click
        btnCifra = new Button("Cifra");
        btnCifra.setBounds(100, 10, 210, 100);
        btnCifra.addActionListener(this);
        
        //Criando caixa de texto
        txtOri = new TextArea  ("");
        txtOri.setBounds(150, 50, 10, 100);
        
        //Criando Rótulo para caixa de texto anterior
        lblOri = new Label("Texto Original:");
        lblOri.setBounds(100, 10, 10, 80);
        
        //Criando caixa de texto sem abilitar edicão
        txtEnc = new TextArea  ("");
        txtEnc.setEditable(false);
        txtEnc.setBounds(150, 50, 10, 240);
        
        //Criando Rótulo para caixa de texto anterior
        lblEnc = new Label("Texto Encriptado:");
        lblEnc.setBounds(100, 10, 10, 220);
        
        //Criando Lista com a quantidade de posições para cifra
        //Carregando os valores e selecionando o primeiro
        cboPos = new List();
        for(int i=1;i<11;i++)
            cboPos.add(String.valueOf(i));
        cboPos.select(0);
        cboPos.setBounds(100, 10, 220, 100);
        
        //Adicionando objetos a tela
        this.add(lblOri);
        this.add(txtOri);
        this.add(lblEnc);
        this.add(txtEnc);
        this.add(cboPos);
        this.add(btnCifra);
        
    }

    //Sobrescrevendo método de ação do botão cifra
    @Override
    public void actionPerformed(ActionEvent e) {
        //Resgatando o texto digitado
        String texto =  txtOri.getText();
        
        //Resgatando posição escolhida
        int pos = new Integer(cboPos.getItem(cboPos.getSelectedIndex()));
        String res = "";
        
        //Alterando o texto para encriptação
        for(int i=0;i<texto.length();i++){
            int ascii = texto.charAt(i);
            res += (char) (ascii+pos); 
        }
        
        //Carregando o texto na caixa com o resultado da encriptação
        txtEnc.setText(res);
    }
}