/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informação - G7 - UAB SJC - Ufscar 
 * Atividade AA6-1
 */
package servlet;

//Carregando bibiliotecas necessárias
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletRaizes extends ServletEquação {

    //Reescrevendo método para resposta http
    @Override
    protected void processRequest(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        
        //Resgatando da sessão as variáveis
        int c1 = (Integer)request.getSession().getAttribute("coeficiente1");
        int c2 = (Integer)request.getSession().getAttribute("coeficiente2");
        int c3 = (Integer)request.getSession().getAttribute("coeficiente3");
        
        //Variáveis auxiliares
        double x1,x2,delta;

        //Escrevendo HTML
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Raízes Reais de equação do segundo grau</title>");
        out.println("</head>");
        out.println("<body>");
        
        //Exibindo valores originais
        out.println("Primeiro Coeficiente: "+c1);
        out.println("<br>");
        out.println("Segundo Coeficiente: "+c2);
        out.println("<br>");
        out.println("Terceiro Coeficiente: "+c3);
        out.println("<br>");
        
        //Calculando Raizes
        delta = Math.pow(c2, 2) - 4 * c1 * c3;
        if(delta == 0){
            x1 = x2 = -c1/(2*c2);
            //Exibindo resultado mesma raiz
            out.println("x1="+x1);
            out.println("<br>");
            out.println("x2="+x1);
        }else{
            if(delta > 0){
                delta = Math.sqrt(delta);
                x1 = ((c2*-1) - delta) / (2*c1);
                x2 = ((c2*-1) + delta) / (2*c1);
                //Exibindo resultado raiz diferentes
                out.println("x1="+x1);
                out.println("<br>");
                out.println("x2="+x2);
            }else{
                //Exibindo resultado sem raiz
                out.println("Equação não possui raízes reais.");
            }
        }
        
        //Finalizando HTML
        out.println("</body>");
        out.println("</html>"); 
        out.close();
    }
}
