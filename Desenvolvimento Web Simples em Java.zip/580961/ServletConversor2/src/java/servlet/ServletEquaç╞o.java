/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informação - G7 - UAB SJC - Ufscar 
 * Atividade AA6-1
 */

package servlet;

//Carregando bibiliotecas necessárias
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ServletEquação extends HttpServlet {

    protected void processRequest(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        try {
            //Atribuindo valores resgatados da caixa de texto na sessão
            HttpSession session = request.getSession();
            String coeficiente1 = request.getParameter("coeficiente1");
            session.setAttribute("coeficiente1", Integer.parseInt(coeficiente1));

            String coeficiente2 = request.getParameter("coeficiente2");
            session.setAttribute("coeficiente2", Integer.parseInt(coeficiente2));

            String coeficiente3 = request.getParameter("coeficiente3");
            session.setAttribute("coeficiente3", Integer.parseInt(coeficiente3));

            //Redirecionado para exibir resultados
            response.sendRedirect("raizes");
                    
        } catch (NumberFormatException exc) {
            //Em caso de valores inválidos
            response.sendRedirect("erro.html");
        }
    }

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
