import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class inscricao extends HttpServlet {
	
	public void init(ServletConfig ConfInicial) throws ServletException
	{
 		// m�todo chamado para inicializar o servlet
 		super.init(ConfInicial);
 	}

	// m�todo chamado para atender uma solicita��o de HTTP POST
 	public void doPost(HttpServletRequest request, HttpServletResponse
	response) throws IOException, ServletException {
 		String nome = request.getParameter("nome");
 		String cpf = request.getParameter("cpf");
 		String email = request.getParameter("email");
 		String telefone = request.getParameter("telefone");
 		String minicurso = request.getParameter("minicurso");

 		PrintWriter saida = response.getWriter();
		saida.println("<!DOCTYPE html>");
		saida.println("<html><head>");
		saida.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=ISO-8859-1\" charset=\"UTF-8\">");
		saida.println("<title>16 Dia de Java/UFSCar - Inscri��es</title>");
		saida.println("<!--Garante o suporte correto do HTML5 para o Internet Explorer-->");
		saida.println("<!--[if lt IE 9]><script src=\"http://html5shiv.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->");
		saida.println("<link rel=\"stylesheet\" href=\"http://localhost:8080/dsw580961/css/estilo.css\" type=\"text/css\" />");
		saida.println("</head><body><header>");
		saida.println("<span id=\"logotipo\"><img src=\"http://localhost:8080/dsw580961/imagens/logotipo_ediadejava.png\"/>");
		saida.println("<span id=\"titulo\">16 Dia de Java/UFSCar</span></span>");
		saida.println("<a href=\"http://localhost:8080/dsw580961/administrador.html\" style=\"padding: 40px;vertical-align: 30px;\">");
		saida.println("<img src=\"http://localhost:8080/dsw580961/imagens/administrador.png\"/> Administrador</a>");
		saida.println("<nav><ul id=\"menu\">");
		saida.println("<li><a href=\"http://localhost:8080/dsw580961/index.html\">In�cio</a></li>");
		saida.println("<li><a href=\"#\">Local</a></li>");
		saida.println("<li><a href=\"#\">Organiza��o</a></li>");
		saida.println("<li><a href=\"#\">Programa��o</a></li>");
		saida.println("<li><a href=\"#\">Palestras</a></li>");
		saida.println("<li><a href=\"#\">Mini-cursos</a></li>");
		saida.println("<li><a href=\"http://localhost:8080/dsw580961/inscricoes.html\"  class=\"ativo\">Inscri��es</a></li>");
		saida.println("<li><a href=\"#\">Contato</a></li>");
		saida.println("</ul></nav></header><section><article>");
		saida.println("<p>O cadastro foi realizado com sucesso:</p>");
		saida.println("<p><label for=\"nome\" style=\"width: 500px;text-align: left;\">Nome: "+nome+"</label></p>");
 		saida.println("<p><label for=\"cpf\" style=\"width: 500px;text-align: left;\">CPF: "+cpf+"</label></p>");
 		saida.println("<p><label for=\"email\" style=\"width: 500px;text-align: left;\">Email: "+email+"</label></p>");
 		saida.println("<p><label for=\"telefone\" style=\"width: 500px;text-align: left;\">Telefone: "+telefone+"</label></p>");
 		saida.println("<p><label for=\"minicurso\" style=\"width: 500px;text-align: left;\">Minicurso: "+minicurso+"</label></p>");
		saida.println("</article></section></body></html>");
	}

 	//m�todo chamado quando o servlet � terminado
 	public void destroy() {
 		System.out.println("Fim do servlet");
 	}
}