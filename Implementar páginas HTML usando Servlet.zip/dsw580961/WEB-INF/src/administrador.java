import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class administrador extends HttpServlet {
	
	public void init(ServletConfig ConfInicial) throws ServletException
	{
 		// m�todo chamado para inicializar o servlet
 		super.init(ConfInicial);
 	}

	// m�todo chamado para atender uma solicita��o de HTTP POST
 	public void doPost(HttpServletRequest request, HttpServletResponse
	response) throws IOException, ServletException {
 		String nome = request.getParameter("nome");
 		String palestrante = request.getParameter("palestrante");
 		String data = request.getParameter("data");
 		String local = request.getParameter("local");
 		String mensagem = request.getParameter("mensagem");

 		PrintWriter saida = response.getWriter();
		saida.println("<!DOCTYPE html>");
		saida.println("<html><head>");
		saida.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=ISO-8859-1\" charset=\"UTF-8\">");
		saida.println("<title>16 Dia de Java/UFSCar - Inscri��es</title>");
		saida.println("<!--Garante o suporte correto do HTML5 para o Internet Explorer-->");
		saida.println("<!--[if lt IE 9]><script src=\"http://html5shiv.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->");
		saida.println("<link rel=\"stylesheet\" href=\"http://localhost:8080/dsw580961/css/estilo.css\" type=\"text/css\" />");
		saida.println("</head><body><header>");
		saida.println("<span id=\"logotipo\"><img src=\"http://localhost:8080/dsw580961/imagens/logotipo_ediadejava.png\"/>");
		saida.println("<span id=\"titulo\">16 Dia de Java/UFSCar</span></span>");
		saida.println("<a href=\"http://localhost:8080/dsw580961/administrador.html\" style=\"padding: 40px;vertical-align: 30px;\">");
		saida.println("<img src=\"http://localhost:8080/dsw580961/imagens/home.png\"/> Home</a>");
		saida.println("<nav><ul id=\"menu\">");
		saida.println("<li><a href=\"http://localhost:8080/dsw580961/administrador.html\">Mini-cursos</a></li>");
		saida.println("</ul></nav></header><section><article>");
		saida.println("<p>O cadastro do minicurso foi realizado com sucesso!</p>");
		saida.println("<p><label for=\"nome\" style=\"width: 500px;text-align: left;\">Nome: "+nome+"</label></p>");
 		saida.println("<p><label for=\"palestrante\" style=\"width: 500px;text-align: left;\">Palestrante: "+palestrante+"</label></p>");
 		saida.println("<p><label for=\"data\" style=\"width: 500px;text-align: left;\">Data: "+data+"</label></p>");
 		saida.println("<p><label for=\"local\" style=\"width: 500px;text-align: left;\">Local: "+local+"</label></p>");
 		saida.println("<p><label for=\"mensagem\" style=\"width: 500px;text-align: left;\">Mensagem: "+mensagem+"</label></p>");
		saida.println("</article></section></body></html>");
	}

 	//m�todo chamado quando o servlet � terminado
 	public void destroy() {
 		System.out.println("Fim do servlet");
 	}
}