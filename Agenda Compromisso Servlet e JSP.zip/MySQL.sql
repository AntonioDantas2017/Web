create database agenda;
use agenda;

create table compromisso(
	codigo integer not null auto_increment,
	titulo text not null,
	tipo text not null,
	dataHora datetime not null,
	local text not null,
	duracao integer not null, 
	observacoes text not null,
    usuario integer not null,
	constraint compromisso_pk Primary Key (codigo)
);

create table usuario(
	codigo integer not null auto_increment,
	login text not null,
	senha text not null,
    nome  text not null,
	ultimoacesso datetime null,
	constraint compromisso_pk Primary Key (codigo)
);

insert into usuario (login,senha,nome) values ('teste','698dc19d489c4e4db73e28a713eab07b','DR TESTE')
/*Login: teste Senha: teste*/



