/*
	Desenvolvimento de Software Avan�ado para Web
	AA4-1 Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581062	Marcio Rog�rio Porto 
 */

package source;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.text.SimpleDateFormat;

//Classe com os dados do compromisso
public class Compromisso
{
	private int codigo;
	private String titulo;
	private String tipo;
	private Date dataHora;
	private String dataHoraMontada;
	private String local;
	private int duracao;
	private String observacoes;
	private int usuario;
	
	//Inicializa Objeto
	public Compromisso()
	{
		codigo = 0;
		titulo="";
		tipo="";
		dataHora=new Date(System.currentTimeMillis());
		local="";
		duracao=0;
		observacoes="";
		usuario=0;	
	}

	//M�todos de Recupera��o
	public int getCodigo() { return codigo; }
	public String getTitulo() { return titulo; }
	public String getTipo() { return tipo; }
	public Date getDataHora() { return dataHora; }
	public String getLocal() { return local; }
	public String getDataHoraMontada() { return dataHoraMontada; }
	public int getDuracao() { return duracao; }
	public String getObservacoes() { return observacoes; }
	public int getUsuario() { return usuario; }
	
	//M�todos de Altera��o
	public void setCodigo (int i) { codigo = i; }
	public void setTitulo (String s) { titulo=s; }
	public void setTipo (String s) { tipo = s; }
	public void setDataHora (Date d) { dataHora=d; }
	public void setLocal (String s) { local=s; }
	public void setDataHoraMontada (String s) { dataHoraMontada=s; }
	public void setDuracao (int i) { duracao = i; }
	public void setUsuario (int i) { usuario = i; }
	public void setObservacoes (String s) {observacoes = s; }
	
	//Insere no Banco de Dados o Compromisso
	public boolean insert()
	{
		boolean retorno = false;
	    ConexaoBD conexao = new ConexaoBD();
	    
	    //Conex�o com o Banco de Dados
	    Connection conn = conexao.getConexao();
	    if(conn != null)
	    {
	    	PreparedStatement p;
	    	try
	    	{
	    		//Atribuindo dados
	    		p = conn.prepareStatement("insert into compromisso (`titulo`,`tipo`,`dataHora`,`local`,`duracao`,`observacoes`,`usuario`) values (?,?,?,?,?,?,?)");
	    		p.setString(1, titulo); 
	    		p.setString(2, tipo);
	    		p.setDate(3, dataHora);
	    		p.setString(4, local);
	    		p.setInt(5, duracao);
	    		p.setString(6, observacoes);
	    		p.setInt(7, usuario);
	    		//Grava no Banco de Dados
	    		p.executeUpdate(); 
	    		retorno = true;
	    	}
	    	catch(SQLException ex)
	    	{
	    		System.err.println("Falha no cadastro: " + ex.getMessage());
	    	}
	    	finally
	        {
	    		conexao.fecharConexao(); //fecha a conexão com o banco de dados
	        }
	    }
	    return retorno;
	}
	
    //Seleciona um compromisso
    public boolean select()
    {
    	boolean retorno = false;
      	ConexaoBD conexao = new ConexaoBD();
      	
      	//Conex�o com o Banco de Dados
      	Connection conn = conexao.getConexao();
      	if(conn != null)
      	{
      		PreparedStatement p;
      		try
      		{
      			p = conn.prepareStatement("select * from compromisso where codigo = ? and usuario = ?");
      			p.setInt(1, codigo);
      			p.setInt(2, usuario);
      			//Executa a instru��o
      			ResultSet r = p.executeQuery(); 
      			if(r.next()) 
      			{
      				//Caso encontre atribui os valores
      				titulo=r.getString(2);
      				tipo=r.getString(3);
      				dataHora=r.getDate(4);
      				local=r.getString(5);;
      				duracao=r.getInt(6);
      				observacoes=r.getString(7);
      				usuario=r.getInt(8);
            		retorno = true;
      			}
      		}
      		catch(SQLException ex)
      		{
      			System.err.println("Falha ao buscar pelo cadastro: " + ex.getMessage());
      		}
      		finally
      		{
      			//Fechar conex�o com BD
      			conexao.fecharConexao();
      		}
      	}
      	return retorno;
    }
    
    //Seleciona todos compromisso
    public List<Compromisso> selectAll(String filtro)
    {
      	ConexaoBD conexao = new ConexaoBD();
      	List<Compromisso> Compromissos = new ArrayList<Compromisso>();
      	boolean retorno = false;
      	
      	//Conex�o com o Banco de Dados
      	Connection conn = conexao.getConexao();
      	if(conn != null)
      	{
      		PreparedStatement p;
      		try
      		{
      			p = conn.prepareStatement("select * from compromisso where (1=1) "+filtro+" order by datahora");
      			//Executa a instru��o
      			ResultSet r = p.executeQuery(); 
      			while(r.next()) 
      			{
      				retorno = true;
      				//Caso encontre atribui os valores
      				Compromisso novo = new Compromisso();
      				novo.setCodigo(r.getInt(1));
      				novo.setTitulo(r.getString(2));
      				novo.setTipo(r.getString(3));
      				String dataFormatada = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(r.getDate(4));
      				novo.setDataHoraMontada(dataFormatada.split(" ")[0] + "<BR>" + dataFormatada.split(" ")[1] );
      				novo.setDataHora(r.getDate(4));
      				novo.setLocal(r.getString(5));
      				novo.setDuracao(r.getInt(6));
      				novo.setObservacoes(r.getString(7));
      				Compromissos.add(novo);
      			}
      			if(retorno == false)
      				Compromissos = null;
      		}
      		catch(SQLException ex)
      		{
      			System.err.println("Falha ao buscar pelo cadastro: " + ex.getMessage());
      		}
      		finally
      		{
      			//Fechar conex�o com BD
      			conexao.fecharConexao();
      		}
      	}
      	return Compromissos;
    }

    //Verifica se existe um compromisso para o intervalo solicitado
    public boolean selectPeriodo(Date date, int duracao)
    {
    	boolean retorno = false;
      	ConexaoBD conexao = new ConexaoBD();
      	
      	//Conex�o com o Banco de Dados
      	Connection conn = conexao.getConexao();
      	if(conn != null)
      	{
      		PreparedStatement p;
      		try
      		{
      			GregorianCalendar gc = new GregorianCalendar();
      		    gc.setTime(date);
      		    //Adiciona a dura��o
      		    gc.add(Calendar.HOUR, duracao);
      		    
      		    //Formata para pesquisa
      		    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
      		    String novaData = sdf.format(gc.getTime());
      		    
      			p = conn.prepareStatement("select * from compromisso where (dataHora between ? and ?) and usuario = ?");
      			p.setDate(1, date);
      			p.setString(2, novaData);
      			p.setInt(3, usuario);
      			
      			//Executa a instru��o
      			ResultSet r = p.executeQuery(); 
      			if(r.next()) 
      			{
            		retorno = true;
      			}
      		}
      		catch(SQLException ex)
      		{
      			System.err.println("Falha ao buscar pelo cadastro: " + ex.getMessage());
      		}
      		finally
      		{
      			//Fechar conex�o com BD
      			conexao.fecharConexao();
      		}
      	}
      	return retorno;
    }

    //Edita um compromisso
    public boolean update()
	{
		boolean retorno = false;
	    ConexaoBD conexao = new ConexaoBD();
	    
	    //Conex�o com o Banco de Dados
	    Connection conn = conexao.getConexao();
	    if(conn != null)
	    {
	    	PreparedStatement p;
	    	try
	    	{
	    		//Atribuindo dados
	    		p = conn.prepareStatement("update compromisso set titulo=?,tipo=?,datahora=?,"
	    				+ "local=?,duracao=?,observacoes=? where codigo=?");
	    		p.setString(1, titulo); 
	    		p.setString(2, tipo);
	    		p.setDate(3, dataHora);
	    		p.setString(4, local);
	    		p.setInt(5, duracao);
	    		p.setString(6, observacoes);
	    		p.setInt(7, codigo);
	    		//Grava no Banco de Dados
	    		p.executeUpdate(); 
	    		retorno = true;
	    	}
	    	catch(SQLException ex)
	    	{
	    		System.err.println("Falha no cadastro: " + ex.getMessage());
	    	}
	    	finally
	        {
	    		conexao.fecharConexao(); //fecha a conexão com o banco de dados
	        }
	    }
	    return retorno;
	}

    //Exclui um compromisso
    public boolean delete()
	{
		boolean retorno = false;
	    ConexaoBD conexao = new ConexaoBD();
	    
	    //Conex�o com o Banco de Dados
	    Connection conn = conexao.getConexao();
	    if(conn != null)
	    {
	    	PreparedStatement p;
	    	try
	    	{
	    		//Atribuindo dados
	    		p = conn.prepareStatement("delete from compromisso where codigo=?");
	    		p.setInt(1, codigo);
	    		//Grava no Banco de Dados
	    		p.executeUpdate(); 
	    		retorno = true;
	    	}
	    	catch(SQLException ex)
	    	{
	    		System.err.println("Falha no cadastro: " + ex.getMessage());
	    	}
	    	finally
	        {
	    		conexao.fecharConexao(); //fecha a conexão com o banco de dados
	        }
	    }
	    return retorno;
	}

}
