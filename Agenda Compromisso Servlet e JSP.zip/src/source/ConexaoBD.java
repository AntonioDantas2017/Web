/*
	Desenvolvimento de Software Avan�ado para Web
	AA4-1 Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581062	Marcio Rog�rio Porto 
 */


package source;

import java.sql.*;

public class ConexaoBD
{
	private Connection conexao;
    
	//M�todo para conex�o com o BD da Aplica��o
    public ConexaoBD()
    {
    	conexao = null;
    	try
    	{
    		//Chama classe do Mysql
    		Class.forName("com.mysql.jdbc.Driver").newInstance(); 
    		//Conecta ao BD
    		conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda","root","dantas0880"); //Faz a conexão com o banco de dados
      }
      catch (Exception excecao)
      {
        System.err.println("Erro ao conectar com o banco: " + excecao.getMessage());
      }
    }
    
    //M�todo para retornar a conex�o estabelecida
    public Connection getConexao()
    {
      return conexao;
    }
    
    //M�todo para fechar conex�o aberta
    public void fecharConexao()
    {
      try
      {
        if( getConexao()!= null)
        {
          if(!conexao.isClosed()) 
            getConexao().close();
        }
      }
      catch (Exception excecao)
      {
        System.err.println("Erro ao fechar a conexao com o banco: " + excecao.getMessage());
      }
    }
}
