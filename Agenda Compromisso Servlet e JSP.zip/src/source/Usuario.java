/*
	Desenvolvimento de Software Avan�ado para Web
	AA4-1 Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581062	Marcio Rog�rio Porto 
 */

package source;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Esta classe representa um usuário do sistema
 */
public class Usuario
{
   private int codigo;
   private String login;
   private String senha;
   private String nome;
   private String ultimoacesso;
   
   public Usuario(String login, String senha) throws NoSuchAlgorithmException
   {
     this.login = login;
     this.senha = getHash(senha); //atribui o hash da senha no campo senha da classe
   }

   public boolean fazerLogin() throws SQLException
   {
     if(select())
      return true;
     return false;
   }

    private boolean select() throws SQLException
    {
      boolean retorno = false;
      ConexaoBD conexao = new ConexaoBD();
      Connection conn = conexao.getConexao(); //faz conexão com o banco de dados
      if(conn != null)
      {
        PreparedStatement p;
        try
        {
          p = conn.prepareStatement("select codigo,nome from usuario where login = ? and senha = ?");
          p.setString(1, login); //seta os campos da query SQL
          p.setString(2, senha);
          ResultSet r = p.executeQuery(); //Executa a query SQL
          if(r.next()) //Então encontrou os dados do paciente
          {
        	  	this.setCodigo(r.getInt(1));
        	  	this.setNome(r.getString(2));
        	  
        	  	SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        	    Date dataAtual = new Date(System.currentTimeMillis());
        	    
        	  	//Atribuindo dados para atualizar ultimo acesso
        	  	PreparedStatement p2;
        	  	Connection conn2 = conexao.getConexao(); //faz conexão com o banco de dados
        	  	p2 = conn2.prepareStatement("update usuario set ultimoacesso = '"+sd.format(dataAtual)+"' where codigo = "+this.getCodigo()+"");
	    		p2.executeUpdate();
        	  
        	  retorno = true;
          }
        }catch(Exception excecao){
        	System.err.println("Erro: " + excecao.getMessage());
        }
        finally
        {
          conexao.fecharConexao(); //fecha a conexão com o banco de dados
        }
      }
      return retorno;
    }

    public void selectLogado() throws SQLException
    {
      ConexaoBD conexao = new ConexaoBD();
      Connection conn = conexao.getConexao(); //faz conexão com o banco de dados
      if(conn != null)
      {
        PreparedStatement p;
        try
        {
          p = conn.prepareStatement("select nome, ultimoacesso from usuario where codigo = ?");
          p.setInt(1, codigo); //seta os campos da query SQL

          ResultSet r = p.executeQuery(); //Executa a query SQL
          if(r.next())
          {
        	  this.setNome(r.getString(1));
        	  this.setUltimoAcesso(r.getString(2));
          }
        }
        catch (Exception excecao)
        {
          System.err.println("Erro ao conectar com o banco: " + excecao.getMessage());
        }
        finally
        {
          conexao.fecharConexao(); //fecha a conexão com o banco de dados
        }
      }
    }

    
   private String getHash(String senha) throws NoSuchAlgorithmException
   {
      MessageDigest algoritmo; //Cria objeto usado para obter instância do algoritmo de criptografia MD5
      algoritmo = MessageDigest.getInstance("MD5"); //define o algoritmo a ser utilizado
      algoritmo.reset(); //por padrão chama reset antes de utilizar
      algoritmo.update(senha.getBytes()); //Fornece os bytes referentes à senha para gerar o hash
      byte [] messageDigest = algoritmo.digest(); //Obtém o hash
      StringBuilder s = new StringBuilder();
      for (int i = 0; i < messageDigest.length; i++) //Compatibiliza o hash do Java com o do MySQL
      {
        int parteAlta = ((messageDigest[i] >> 4) & 0xf) << 4; //Faz deslocamento de bits e AND lógico
        int parteBaixa = messageDigest[i] & 0xf; //faz AND lógico com o hash e 0xF
        if (parteAlta == 0) //Se parte alta for 0, concatena um 0 na string que representa o hash
          s.append('0');
        s.append(Integer.toHexString(parteAlta | parteBaixa)); //faz OR lógico entre a parte alta e parte baixa
      }
      return s.toString(); //Retorna a string que representa o hash da senha
   }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }    
    
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }
    
    public void setUltimoAcesso(String ultimoacesso) {
        this.ultimoacesso = ultimoacesso;
    }

    public String getUltimoAcesso() {
        return ultimoacesso;
    }
    
    public void setSenha(String senha) {
        this.senha = senha;
    }

}
