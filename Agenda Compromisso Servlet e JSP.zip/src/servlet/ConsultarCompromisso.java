/*
	Desenvolvimento de Software Avan�ado para Web
	AA4-1 Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581062	Marcio Rog�rio Porto 
 */

package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import source.Compromisso;

public class ConsultarCompromisso extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ConsultarCompromisso() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String msgRetorno = "";
        Compromisso compromisso = new Compromisso();
        
        try
        {
            //Busca dados por meio do filtro do c�digo
        	compromisso.setCodigo(Integer.parseInt(request.getParameter("codigo")));
           	HttpSession sessao = request.getSession(true); 				
            compromisso.setUsuario(Integer.parseInt(sessao.getAttribute("codigoUsuario").toString()));

            if(compromisso.select())
            {
            	//Recupera os dados da pesquisa
            	msgRetorno += "C�digo: "+compromisso.getCodigo()+"<br>";
            	msgRetorno += "Titulo: "+compromisso.getTitulo()+"<br>";
            	msgRetorno += "Tipo: "+compromisso.getTipo()+"<br>";
            	msgRetorno += "Data e Hora: "+compromisso.getDataHora()+"<br>";
            	msgRetorno += "Local: "+compromisso.getLocal()+"<br>";
            	msgRetorno += "Dura��o(Horas): "+compromisso.getDuracao()+"<br>";
            	msgRetorno += "Observa��es: "+compromisso.getObservacoes()+"<br>";
            }else{
            	msgRetorno = "Compromisso n�o encontrado";
            }
        } 
        catch (Exception ex)
        {
        	//Exce��es n�o especificadas
            msgRetorno = ex.getMessage();
        } 
        finally
        {
        	//Apresenta��o da p�gina
        	out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1- transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Home</title><link rel=\"stylesheet\" href=\"css/estilo.css\" type=\"text/css\"/></head><body><header><img src=\"image/logotipo_ufscar.png\" alt=\"Universidade Federal de S�o Carlos\" id=\"logotipo\"/><span id=\"titulo\">Desenvolvimento de Software Avan�ado para Web</span><nav><ul id=\"menu\"><li><a href=\"home.html\" id=\"ativo\">Inicio</a></li><li><a href=\"login\">Login</a></li><li><a href=\"cadastrar.jsp\">Cadastrar</a></li><li><a href=\"consultar.jsp\">Consultar</a></li><li><a href=\"Listar.jsp\">Listar</a></li><li><a href=\"desenvolvedores.jsp\">Desenvolvedores</a></li><li><a href=\"ajuda.jsp\">Ajuda</a></li></ul></nav></header><section><h2 align=\"center\">Agenda de Compromissos</h2><hr id=\"linhaSuperior\" align=\"center\" /><img src=\"image/compromisso.png\" alt=\"Compromisso\" id=\"logocompromisso\" />");
            out.write("<p id=\"paragrafo1\">"+msgRetorno+"</p>");
            out.write("</section></body></html>");
            out.close();
        }
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
