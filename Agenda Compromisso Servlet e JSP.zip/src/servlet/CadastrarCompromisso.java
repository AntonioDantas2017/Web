/*
	Desenvolvimento de Software Avan�ado para Web
	AA4-1 Atividade Avaliativa
	580961	Antonio Josivaldo Dantas Filho
	581062	Marcio Rog�rio Porto 
 */

package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import source.Compromisso;

public class CadastrarCompromisso extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CadastrarCompromisso() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String msgRetorno = "";
        Compromisso compromisso = new Compromisso();
        
        try
        {
        	Date data = null;
        	int duracao = 0;
        	
        	//Verificar se data � v�lida
        	try{
        		String dt = request.getParameter("txtData");
        		String hr = request.getParameter("txtHora");
        		java.util.Date dataUtil = new java.util.Date();
        		dataUtil.setDate(Integer.parseInt(dt.split("/")[0]));
        		dataUtil.setMonth(Integer.parseInt(dt.split("/")[1]));
        		dataUtil.setYear(Integer.parseInt(dt.split("/")[2]));
        		dataUtil.setHours(Integer.parseInt(hr.split(":")[0]));
        		dataUtil.setMinutes(Integer.parseInt(hr.split(":")[1]));
        		dataUtil.setSeconds(0);
        		data = new java.sql.Date(dataUtil.getTime());
        		
        	}catch (Exception ex){
        		msgRetorno = "Data e/ou Hora em formato Inv�lido";
        	}
        	
        	//Verificar se dura��o � um n�mero
        	try{
        		duracao = Integer.parseInt(request.getParameter("txtDuracao"));
        	}catch (Exception ex){
        		msgRetorno = "Dura��o em formato Inv�lido";
        	}
        	
        	//Verifica se dura��o � maior que 0
        	if(duracao > 0 && data != null)
        	{
        		//Verifica se o compromisso existe conflito
        		if (compromisso.selectPeriodo(data, duracao))
                {
                    msgRetorno = "Compromisso em conflito com outro j� marcado";
                }
        	}else{
        		msgRetorno = "Dura��o deve ser maior que 0";
        	}
        	
        	//Recupera par�metros
            String titulo = request.getParameter("txtTitulo");
            String observacoes = request.getParameter("txtObservacoes");
            String local = request.getParameter("txtLocal");
            
            //Verifica se algum par�metro � vazio
            if (titulo == null || titulo.equals("") || observacoes == null || observacoes.equals("") || local == null || local.equals(""))
            {
            	msgRetorno = "Todos os campos precisam ser preenchidos";
            }
            
            //Verifica se a data � maior que a corrente
            if (data.getTime() < System.currentTimeMillis())
            {
            	msgRetorno = "Voc� digitou uma data e/ou hora inv�lida";
            }
            
            //Verifica se as valida��es foram aceitas
            if(msgRetorno.equals(""))
            {
            	//Atribui os valores ao objeto
            	compromisso.setDataHora(data);
                compromisso.setDuracao(duracao);
                compromisso.setTitulo(titulo);
                compromisso.setTipo(request.getParameter("txtTipo"));
                compromisso.setLocal(local);
                compromisso.setDuracao(duracao);
                compromisso.setObservacoes(observacoes);
                
                HttpSession sessao = request.getSession(true); 				
                compromisso.setUsuario(Integer.parseInt(sessao.getAttribute("codigoUsuario").toString()));

                
                //Realiza a inser��o no banco de dados
                if (compromisso.insert()) 
                    msgRetorno = "Cadastro do Compromisso realizado com sucesso!";
                else
                    msgRetorno = "Falha ao cadastrar o paciente";
            }
            
        } 
        catch (Exception ex)
        {
        	//Exce��es n�o especificadas
        	msgRetorno = ex.getMessage();
        } 
        finally
        {
        	//Apresenta��o da p�gina
            out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1- transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Home</title><link rel=\"stylesheet\" href=\"css/estilo.css\" type=\"text/css\"/></head><body><header><img src=\"image/logotipo_ufscar.png\" alt=\"Universidade Federal de S�o Carlos\" id=\"logotipo\"/><span id=\"titulo\">Desenvolvimento de Software Avan�ado para Web</span><nav><ul id=\"menu\"><li><a href=\"home.html\" id=\"ativo\">Inicio</a></li><li><a href=\"login\">Login</a></li><li><a href=\"cadastrar.jsp\">Cadastrar</a></li><li><a href=\"consultar.jsp\">Consultar</a></li><li><a href=\"Listar.jsp\">Listar</a></li><li><a href=\"desenvolvedores.jsp\">Desenvolvedores</a></li><li><a href=\"ajuda.jsp\">Ajuda</a></li></ul></nav></header><section><h2 align=\"center\">Agenda de Compromissos</h2><hr id=\"linhaSuperior\" align=\"center\" /><img src=\"image/compromisso.png\" alt=\"Compromisso\" id=\"logocompromisso\" />");
            out.write("<p id=\"paragrafo1\">"+msgRetorno+"</p>");
            out.write("</section></body></html>");
            out.close();
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
